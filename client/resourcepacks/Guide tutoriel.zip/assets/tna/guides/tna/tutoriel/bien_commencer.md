---
navigation:
  # Title shown in the navigation bar
  title: Bien commencer
  # [OPTIONAL] The page ID of the parent this page should be sorted under as a child entry
  # If it's in the same namespace as the current page, the namespace can be omitted, otherwise use "ae2:path/to/file.md"
  parent: index.md
  # [OPTIONAL] The position of this page in the navigation bar as a number
  # Pages are sorted by their position value with the title acting as a tie-breaker
  position: 2
---

# 2. Bien commencer (Les premiers jours)

Les premiers jours peuvent être intimidants avec tous ces nouveaux biomes (merci TerraBlender, Better End et Better Nether !). Voici comment assurer votre survie et ne pas rager à la première difficulté.

---

## <ItemImage id="gravestone:gravestone"/> Ne pas paniquer en cas de mort (Gravestone Mod)
Vous êtes mort bêtement face à un mob mutant ou en tombant dans la lave ? Gardez votre calme.

Grâce au **Gravestone Mod**, tous vos objets, votre armure et votre expérience sont conservés en sécurité dans une tombe à l'endroit exact de votre décès.
* **Comment récupérer votre stuff :** Retournez sur les lieux de votre mort et cassez simplement la tombe.
* **Le papier de décès :** À votre réapparition, vous recevrez un papier (Obituary) avec les coordonnées précises de votre tombe. N'hésitez pas à créer un waypoint Journeymap avec ces coordonnées !

![Exemple de note](assets/gravestone_note_example.png)
![Exemple de tombe Gravestone](assets/gravestone_tomb_example.png)

---

## <ItemImage id="sophisticatedbackpacks:backpack"/> Gérer son inventaire (Sophisticated Backpacks)
L'exploration va remplir vos poches à une vitesse folle. Le premier objectif de tout bon survivant sur ce serveur est de se fabriquer un sac à dos.

* **Les niveaux :** Sophisticated Backpacks propose des sacs améliorables pour augmenter leur capacité (cuir, fer, or, diamant...).
* **Les améliorations (Upgrades) :** Les sacs disposent d'emplacements pour y glisser des modules très pratiques : ramassage automatique, alimentation automatique, filtres de tri, compresseurs, etc.
* **Accès rapide :** Vous pouvez configurer une touche dans vos contrôles pour ouvrir votre sac à dos directement sur votre dos, sans avoir à le poser au sol.

![Interface d'un sac à dos avec améliorations](assets/backpack_example.png)

---

## <ItemImage id="comforts:sleeping_bag_green"/> Confort et Survie en exploration (AppleSkin & Comforts)
Partir loin de sa base nécessite un minimum d'organisation.

* **Comprendre la faim (AppleSkin) :** Lorsque vous tenez de la nourriture dans votre main, votre barre de faim clignote pour montrer combien de points seront restaurés. La bordure jaune qui apparaît indique la "saturation" (votre réserve d'énergie cachée avant de commencer à avoir faim à nouveau).
* **Passer la nuit (Comforts) :** Fabriquez un **Sac de couchage (Sleeping Bag)** ! Contrairement au lit classique, dormir dans un sac de couchage permet de passer la nuit et d'éviter l'apparition de monstres **sans réinitialiser votre point de réapparition**. C'est le meilleur ami des explorateurs.

---

## <ItemImage id="createnuclear:enriched_yellowcake"/> Outils rapides et Qualité de vie (Clumps & Crafting Tweaks)
Le modpack inclut quelques petits ajouts qui rendent le jeu au quotidien beaucoup plus fluide :

* **Moins de lag, plus d'XP (Clumps) :** Les orbes d'expérience lâchées par les monstres ou le minage se regroupent instantanément en une seule grosse orbe. Fini le lag avec 500 petites boules d'XP par terre, et le ramassage est immédiat.
* **Crafting Tweaks :** Dans votre table de craft ou votre inventaire, vous verrez de nouveaux petits boutons. Ils vous permettent de vider la grille d'un clic, d'équilibrer les objets (super pratique pour faire rapidement des séries de coffres ou de fours) ou de faire pivoter les éléments de la recette.