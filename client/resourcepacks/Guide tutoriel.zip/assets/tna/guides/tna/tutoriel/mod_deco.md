---
navigation:
  # Title shown in the navigation bar
  title: Décoration et Architecture
  # [OPTIONAL] The page ID of the parent this page should be sorted under as a child entry
  # If it's in the same namespace as the current page, the namespace can be omitted, otherwise use "ae2:path/to/file.md"
  parent: guide_technologie.md
  # [OPTIONAL] The position of this page in the navigation bar as a number
  # Pages are sorted by their position value with the title acting as a tie-breaker
  position: 5
---

## 5. Décoration et Architecture (Donner vie à votre base)

Parce qu'une usine fonctionnelle ne doit pas forcément être laide, vous avez tout ce qu'il faut sur le serveur pour construire de magnifiques bâtiments et aménager vos intérieurs.

* **Create Deco & Create Interiors :** Indispensables pour donner du cachet à vos usines. Ces mods ajoutent des passerelles métalliques, des briques industrielles, d'immenses portes d'entrepôt, des ventilateurs décoratifs et des supports de poutres pour un look 100% industriel.
* **Design n' Decor :** Parfait pour meubler l'intérieur de vos bases, vos postes de contrôle ou les cabines de vos vaisseaux spatiaux avec des objets modernes et ultra-détaillés.
* **Quark :** Un mod qui améliore le jeu de base (Vanilla+) en douceur. Il ajoute des dizaines de variantes de blocs (murs, escaliers, bibliothèques pour chaque type de bois), des coffres spécifiques à chaque bois, et de nouveaux blocs de construction naturels magnifiques comme le calcaire ou le marbre.
* **Exposure :** Le mod pour les artistes ! Fabriquez un véritable appareil photo, développez vos pellicules et encadrez vos meilleures captures (comme vos amis qui tombent accidentellement de votre dirigeable) pour les afficher fièrement sur les murs de votre base.