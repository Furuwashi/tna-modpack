---
navigation:
  # Title shown in the navigation bar
  title: Draconic Evolution
  # [OPTIONAL] The page ID of the parent this page should be sorted under as a child entry
  # If it's in the same namespace as the current page, the namespace can be omitted, otherwise use "ae2:path/to/file.md"
  parent: guide_technologie.md
  # [OPTIONAL] The position of this page in the navigation bar as a number
  # Pages are sorted by their position value with the title acting as a tie-breaker
  position: 4
---

## 4. Draconic Evolution (L'ère divine)

C'est le sommet absolu de la chaîne alimentaire sur le serveur. Ce mod nécessite énormément de ressources (notamment le Draconium, que l'on trouve principalement dans l'End) et de l'énergie en quantités astronomiques.

* **Armement et Armures :** L'équipement draconique vous rend presque invulnérable. Les armes peuvent être améliorées à l'extrême pour détruire de larges zones d'un seul clic ou tuer les boss les plus redoutables en un seul coup.
* **Stockage d'énergie :** Le *Draconic Energy Core* est une structure flottante géante à construire vous-même, capable de stocker des milliards d'unités d'énergie. Indispensable pour alimenter vos armures !
* **Le Réacteur Draconique :** C'est la source d'énergie ultime du jeu, mais aussi la plus dangereuse. S'il n'est pas refroidi ou contrôlé correctement via des systèmes logiques, il explosera et détruira absolument tout dans un rayon gigantesque, en ignorant les protections de claim. À manipuler avec la plus grande prudence et très loin de votre base principale !