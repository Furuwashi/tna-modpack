---
navigation:
  # Title shown in the navigation bar
  title: Mon premier dirigeable
  # [OPTIONAL] The page ID of the parent this page should be sorted under as a child entry
  # If it's in the same namespace as the current page, the namespace can be omitted, otherwise use "ae2:path/to/file.md"
  parent: index.md
  # [OPTIONAL] The position of this page in the navigation bar as a number
  # Pages are sorted by their position value with the title acting as a tie-breaker
  position: 4
---

# 4. Mon premier dirigeable (L'ère du vol atmosphérique)

C'est ici que notre serveur prend toute sa dimension. Oubliez les longs et dangereux voyages à pied : il est temps de conquérir le ciel ! Avec Create Aeronautics, vous allez pouvoir concevoir, construire et piloter vos propres aéronefs de A à Z.

---

## <ItemImage id="simulated:physics_assembler"/> La physique des blocs (L'assemblage)
Dans Minecraft classique, les blocs sont figés. Avec Create Aeronautics, vos constructions prennent vie et deviennent soumises aux lois de la physique.

* **Le principe :** Vous construisez d'abord la coque de votre navire de manière statique, directement sur le sol ou sur des échafaudages, comme n'importe quelle structure.
* **L'entité physique :** Une fois la construction terminée, vous allez utiliser les outils d'assemblage du mod pour "compiler" votre création. La structure statique se détache alors du monde pour devenir une véritable entité physique mobile.
* **La masse compte :** Chaque bloc a un poids défini. Un dirigeable blindé avec du fer sera beaucoup plus lourd et difficile à soulever qu'un navire léger en bois !

![Exemple d'un navire en cours d'assemblage](assets/create-aeronautic_safe_boat_example.png)
![Exemple d'un navire en cours d'assemblage](assets/create-aeronautic_unsafe_boat_example.png)
---

## <ItemImage id="immersiveengineering:balloon"/> La flottaison et la propulsion
Pour qu'un assemblage de blocs devienne un dirigeable fonctionnel, il a besoin de portance (pour vaincre la gravité) et de poussée (pour se déplacer).

* **Les Ballons :** Ils sont le cœur de votre flottaison. Plus votre vaisseau est lourd, plus le volume de ballons nécessaire pour le maintenir en l'air sera important.
* **Les Hélices (Propellers) :** Elles fournissent la force motrice et dirigent le flux d'air pour vous faire avancer, reculer, ou même monter et descendre selon leur orientation.
* **L'énergie embarquée :** Les hélices ne tournent pas par magie. Vous allez devoir embarquer de quoi générer de l'énergie cinétique. Avec **Create: Sound of Steam** et vos générateurs, construisez une chaudière à bord pour utiliser la force de la vapeur et animer vos moteurs en plein vol !

---

## <ItemImage id="minecraft:compass"/> Le pilotage (Et la vue !)
Avoir un moteur puissant est inutile si vous vous écrasez sur la première montagne venue. Le contrôle de votre appareil est vital.

* **Le Gouvernail :** Placez-le stratégiquement pour pouvoir orienter le nez de votre dirigeable vers la gauche ou la droite.
* **Le Contrôle de bord :** Vous devrez relier vos interfaces de pilotage aux différents éléments mobiles de votre vaisseau. En vous asseyant aux commandes, vous pourrez gérer la vitesse de vos hélices, l'orientation du gouvernail et l'altitude.
* **Profitez du panorama :** Une fois en l'air, stabilisez votre altitude et regardez par la fenêtre. C'est le moment parfait pour apprécier la puissance de **Distant Horizons**, qui vous permet d'admirer des paysages s'étendant sur des dizaines de kilomètres sans faire fondre votre ordinateur.
