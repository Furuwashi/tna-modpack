---
navigation:
  # Title shown in the navigation bar
  title: Immersive Engineering
  # [OPTIONAL] The page ID of the parent this page should be sorted under as a child entry
  # If it's in the same namespace as the current page, the namespace can be omitted, otherwise use "ae2:path/to/file.md"
  parent: guide_technologie.md
  # [OPTIONAL] The position of this page in the navigation bar as a number
  # Pages are sorted by their position value with the title acting as a tie-breaker
  position: 2
---

## 2. Immersive Engineering (L'ère industrielle rétro)

Si vous aimez l'esthétique "Steampunk / Dieselpunk" avec de gros câbles électriques suspendus, des étincelles et d'immenses usines à ciel ouvert, c'est ce mod qu'il vous faut. 

* **Machines Multiblocs :** Ici, pas de petite machine magique tenant dans un seul bloc. Vous allez devoir construire des structures massives et réalistes (broyeurs géants, excavatrices, fours à arc électrique) bloc par bloc en utilisant le manuel du mod. Prévoyez de l'espace dans votre base !
* **L'Excavatrice :** C'est l'un des plus grands atouts d'Immersive Engineering. Elle permet de miner des filons de minerais infinis générés spécifiquement sous la map. Une fois installée, elle vous assure une source de ressources constante.
* **Esthétique et Câblage :** La gestion de l'énergie (RF/FE) se fait de manière très visuelle via des poteaux électriques et des fils tendus entre des relais. C'est magnifique, mais prudence : attention à ne pas toucher les câbles haute tension sans isolation, l'électrocution est fatale !