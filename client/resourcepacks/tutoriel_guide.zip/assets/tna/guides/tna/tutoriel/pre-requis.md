---
navigation:
  # Title shown in the navigation bar
  title: Pré-requis
  # [OPTIONAL] The page ID of the parent this page should be sorted under as a child entry
  # If it's in the same namespace as the current page, the namespace can be omitted, otherwise use "ae2:path/to/file.md"
  parent: index.md
  # [OPTIONAL] The position of this page in the navigation bar as a number
  # Pages are sorted by their position value with the title acting as a tie-breaker
  position: 1
---

# 1. Pré-requis (Les commandes et outils vitaux)

Bienvenue sur le serveur ! Considérez cette section comme le manuel "Lisez-moi avant de pleurer". Notre modpack est riche, et ces outils vont vous sauver la vie (littéralement et métaphoriquement). Avant de construire des dirigeables ou des fusées, maîtrisez les bases !

---

## 🗺 La Carte et les Waypoints (Journeymap)
Ne perdez plus jamais votre base après une longue exploration !

* **Ouvrir la carte complète :** Appuyez sur la touche `J`.
* **Créer un point de repère (Waypoint) :** Appuyez sur `B` ou ouvrez la carte (`J`) et cliquez sur le bouton en forme de losange. C'est indispensable pour retrouver votre maison, un donjon intéressant ou une ressource rare.
* **Minimap :** Elle est affichée en permanence dans le coin de votre écran pour vous orienter rapidement.

![Aperçu de la carte Journeymap](assets/journey-map_example.png)

> **Astuce :** Vous pouvez afficher ou masquer la minimap dans les options de Journeymap (touche `J` puis Paramètres) si elle vous gêne en combat.

---

## 📚 L'encyclopédie des crafts (JEI)
Ne cherchez plus les recettes sur internet, tout est en jeu grâce à **Just Enough Items (JEI)**.

* Ouvrez votre inventaire (`E`). La liste de tous les blocs et objets du jeu apparaît à droite.
* Utilisez la **barre de recherche** en bas à droite pour trouver un objet spécifique (astuce: tapez `@create` pour voir tous les objets du mod Create).
* **Touche `R` (Recette) :** Survolez un objet avec votre souris et appuyez sur `R` pour voir comment le fabriquer.
* **Touche `U` (Utilisation) :** Survolez un objet et appuyez sur `U` pour voir dans quelles recettes il est utilisé.

---

## 🔍 Savoir ce qu'on regarde (Jade)
Face à un bloc inconnu d'une autre dimension ou à une machine complexe ? Regardez en haut au centre de votre écran.

L'encart **Jade** vous indique instantanément :
1. Le nom exact du bloc.
2. Le mod dont il provient (pratique pour le chercher ensuite dans JEI !).
3. Son état actuel (ex: quantité d'énergie stockée, contenu d'un coffre, temps de pousse d'une culture).

![Exemple de l'interface Jade](assets/jade_lever_example.png)

---

## 🔀 Résoudre les conflits de recettes (Polymorph)
Avec autant de mods installés, il arrive fréquemment que deux objets différents se fabriquent de la même manière (par exemple, deux types de planches de bois différentes). Pas de panique !

Grâce au mod **Polymorph**, si une recette a plusieurs résultats possibles, un **petit bouton** apparaîtra au-dessus de la case de résultat dans votre table de craft. Cliquez dessus pour choisir l'objet exact que vous souhaitez fabriquer. Fini la frustration !

---

## 🎤 Le Chat Vocal (Simple Voice Chat)
La communication est la clé, surtout pour se coordonner lors du pilotage d'un vaisseau ou pour crier à l'aide quand un mob d'Alex's Mobs vous poursuit.

* **Menu Voice Chat :** Appuyez sur `V` pour ouvrir les paramètres.
* **Configuration :** Vérifiez que votre micro et vos haut-parleurs sont bien sélectionnés dans l'onglet des paramètres (l'icône d'engrenage).
* **Ajustements :** Vous pouvez régler le volume des autres joueurs individuellement ou créer des groupes privés pour ne pas déranger les autres.

![Menu du chat vocal](assets/voice-chat_example.png)