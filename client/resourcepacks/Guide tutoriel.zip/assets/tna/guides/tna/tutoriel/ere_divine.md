---
navigation:
  # Title shown in the navigation bar
  title: L'ère Divine
  # [OPTIONAL] The page ID of the parent this page should be sorted under as a child entry
  # If it's in the same namespace as the current page, the namespace can be omitted, otherwise use "ae2:path/to/file.md"
  parent: index.md
  # [OPTIONAL] The position of this page in the navigation bar as a number
  # Pages are sorted by their position value with the title acting as a tie-breaker
  position: 6
---

# 6. L'ère Divine (Le défi ultime)

Félicitations, si vous lisez ceci, c'est que vous avez conquis la terre, le ciel et l'espace. Il est maintenant temps de transcender les lois de la physique et de plier la réalité à votre volonté. Bienvenue dans le véritable "Endgame" du serveur, réservé aux experts absolus de l'automatisation.

---

## <ItemImage id="draconicevolution:overworld_draconium_ore"/> La puissance absolue (Draconic Evolution)
Le mod **Draconic Evolution** vous offre des capacités littéralement divines, mais à un coût en ressources et en énergie qui donne le vertige.

* **Les Équipements Divins :** Oubliez le diamant et la netherite. L'armure draconique vous rend virtuellement invincible grâce à son bouclier énergétique et vous offre un vol parfait. Les armes, comme le Bâton de Puissance (Staff of Power), peuvent miner des montagnes entières en un clic et anéantir n'importe quelle créature.
* **Le Cœur d'Énergie (Energy Core) :** Vos anciennes batteries Mekanism ou Immersive Engineering vont vite devenir obsolètes. Pour alimenter votre nouvel arsenal, vous devrez construire un noyau d'énergie multiblock gigantesque en lévitation. À son niveau maximum, il peut stocker des milliards de RF !
* **L'Artisanat de Fusion :** Pour créer ces merveilles, vous devrez maîtriser les Injecteurs de Fusion. Ce système de craft demande des matériaux rares et des quantités massives d'énergie pour fusionner les objets entre eux.

---

## <ItemImage id="createnuclear:yellow_anti_radiation_helmet"/> Attention, danger de mort (Le Réacteur Draconique)
Pour générer l'énergie colossale requise par votre base et votre armure, la solution ultime est le Réacteur Draconique. Mais c'est une machine à double tranchant qu'il ne faut pas prendre à la légère.

* **Une gestion millimétrée :** Ce n'est pas un générateur qu'on allume pour l'oublier ensuite. Le réacteur consomme de l'Awakened Draconium et demande une gestion informatique précise (via des portes logiques ou des moniteurs) de sa température, de son champ de confinement et de son taux de saturation.
* **Le Champ de Confinement :** Vous devez obligatoirement réinjecter une partie de l'énergie produite dans le réacteur pour maintenir le champ de force qui retient la réaction.
* **L'Explosion Nucléaire :** Si vous êtes à court de carburant, ou si votre système faillit et que le champ de confinement tombe à 0%, la réaction s'emballe. C'est l'explosion nucléaire assurée. Le souffle est titanesque, ignorant vos claims et détruisant tous les blocs jusqu'à la bedrock sur un rayon immense. Ne construisez JAMAIS ce réacteur au milieu de votre base principale !

![Un réacteur draconique en cours de fonctionnement](assets/draconic_evolution_example.png)