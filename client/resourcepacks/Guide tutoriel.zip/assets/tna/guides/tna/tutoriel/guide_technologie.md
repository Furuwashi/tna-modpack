---
navigation:
  title: "Guide des technologies"
  icon: "create:wrench"
---

# <ItemImage id="create:wrench"/> Guide des Technologies

Ce supplément vous aidera à choisir votre voie technologique et à comprendre quel mod utiliser pour réaliser vos projets les plus fous. Que vous soyez un ingénieur mécanique de la première heure, un chimiste de pointe ou un architecte d'intérieur, vous trouverez ici la documentation nécessaire.

---

## Les Piliers Technologiques
Découvrez en détail le fonctionnement et les spécialités des grands mods industriels du serveur :

* **[L'univers "Create" et ses Add-ons](mod_create.md)**
  *L'ingénierie mécanique : maîtrisez l'énergie cinétique pour construire des usines animées, des trains massifs et des aéronefs à vapeur.*

* **[Immersive Engineering](mod_immersive-engineering.md)**
  *L'ère industrielle rétro : bâtissez d'immenses machines multiblocs, forez le sol avec des excavatrices et tendez vos câbles haute tension.*

* **[Mekanism](mod_mekanism.md)**
  *La science-fiction et l'optimisation : multipliez vos rendements de minerais, automatisez le minage proprement et préparez vos combinaisons spatiales.*

* **[Draconic Evolution](mod_draconic-evolution.md)**
  *L'ère divine : atteignez le sommet de la puissance avec des armures invincibles et des réacteurs surpuissants (et très dangereux).*

---

## L'Art de la Construction
Parce qu'une base optimisée mérite aussi d'être belle à regarder :

* **[Décoration et Architecture](mod_deco.md)**
  *Donnez vie à vos créations : passerelles métalliques industrielles, mobilier moderne, photographie et nouveaux matériaux de construction.*