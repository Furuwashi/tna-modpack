---
navigation:
  title: "Accueil"
  icon: "minecraft:compass"
---

# <ItemImage id="minecraft:compass"/> Guide de Survie Teck & Aeronautic

Bienvenue, explorateur ! Ce manuel est votre compagnon de route indispensable pour maîtriser les technologies complexes et les nouveaux horizons de ce monde. Suivez les étapes dans l'ordre pour une progression fluide et sans encombre.

---

## <ItemImage id="minecraft:writable_book"/> Votre Carnet de Route
Embarquez dans une aventure qui vous mènera de la simple survie jusqu'à la conquête des étoiles et de l'énergie divine.

### 1. [Pré-requis et Outils Vitaux](pre-requis.md)
Apprenez à utiliser la carte, le chat vocal et les interfaces indispensables pour comprendre votre environnement.

### 2. [Bien commencer en survie](bien_commencer.md)
Gérez votre faim, sécurisez votre équipement en cas de mort et fabriquez votre premier sac à dos.

### 3. [Ma première base et automatisation](premiere_base.md)
Revendiquez votre terrain, organisez votre stockage et découvrez la force cinétique du mod Create.

### 4. [Mon premier dirigeable](premier_dirigable.md)
Prenez de la hauteur ! Apprenez les bases de l'aéronautique pour construire votre premier navire volant.

### 5. [Mon premier vaisseau spatial](premier_vaisseau.md)
Passez à l'ère électrique, fabriquez vos fusées et préparez-vous à quitter l'atmosphère.

### 6. [L'ère Divine : Le défi ultime](ere_divine.md)
Manipulez la puissance draconique et atteignez le sommet de la technologie... à vos risques et périls.

---

## <ItemImage id="create:wrench"/> Annexes et Détails Techniques
Si vous cherchez des précisions sur un mod spécifique ou si vous voulez optimiser vos usines, consultez notre guide spécialisé :

* **[Consulter le Guide détaillé des Technologies](guide_technologie.md)**
  *Focus sur Create, Immersive Engineering, Mekanism et la décoration.*

---

Dernière mise à jour du guide : 2026. Bonne chance !