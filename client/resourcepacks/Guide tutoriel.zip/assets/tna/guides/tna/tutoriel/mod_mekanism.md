---
navigation:
  # Title shown in the navigation bar
  title: Mekanism
  # [OPTIONAL] The page ID of the parent this page should be sorted under as a child entry
  # If it's in the same namespace as the current page, the namespace can be omitted, otherwise use "ae2:path/to/file.md"
  parent: guide_technologie.md
  # [OPTIONAL] The position of this page in the navigation bar as a number
  # Pages are sorted by their position value with the title acting as a tie-breaker
  position: 3
---

## 3. Mekanism (La science-fiction et l'optimisation)

C'est le mod de l'industrie propre, des tuyaux et de la très haute technologie. C'est l'allié idéal pour préparer votre conquête spatiale et maximiser vos ressources.

* **Le traitement des minerais :** Mekanism permet d'augmenter drastiquement vos rendements. En construisant la bonne chaîne d'usines chimiques, un seul minerai brut peut être multiplié pour donner jusqu'à 5 lingots !
* **Le Digital Miner :** C'est le rêve de tout mineur. Cette machine de minage automatique est capable de filtrer et d'extraire exactement les minerais que vous voulez dans un très large rayon, sans détruire la roche autour (fini les immenses trous moches sous votre base).
* **Énergie et Équipement :** Avec l'extension *Mekanism Generators*, vous pourrez construire des réacteurs à fusion ou à fission surpuissants. Cette énergie colossale vous servira notamment à recharger la Meka-Suit : une armure modulaire de science-fiction, quasi-indestructible, qui vous permet de voler et de survivre dans les environnements spatiaux les plus hostiles.