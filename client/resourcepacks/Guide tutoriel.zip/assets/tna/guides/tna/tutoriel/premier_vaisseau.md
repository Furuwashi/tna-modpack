---
navigation:
  # Title shown in the navigation bar
  title: Mon premier vaisseau
  # [OPTIONAL] The page ID of the parent this page should be sorted under as a child entry
  # If it's in the same namespace as the current page, the namespace can be omitted, otherwise use "ae2:path/to/file.md"
  parent: index.md
  # [OPTIONAL] The position of this page in the navigation bar as a number
  # Pages are sorted by their position value with the title acting as a tie-breaker
  position: 5
---

# 5. Mon premier vaisseau (L'ère de l'industrie spatiale)

Vous avez dompté les cieux avec vos dirigeables à vapeur, mais le véritable objectif se trouve bien plus haut. Préparez-vous à repousser les limites de l'ingénierie et à conquérir les étoiles !

---

## La transition énergétique (RF/FE)
L'énergie mécanique de Create a fait ses preuves, mais la conquête spatiale requiert une puissance bien supérieure. Il est temps de passer à l'ère électrique.

* **La nouvelle énergie :** Vous allez devoir générer, transporter et stocker de l'énergie sous forme de RF (Redstone Flux) ou FE (Forge Energy).
* **Les pionniers de l'industrie :** Tournez-vous vers **Immersive Engineering** pour des installations massives, des câbles suspendus et un style industriel réaliste. Si vous préférez la haute technologie et l'optimisation extrême, **Mekanism** sera votre meilleur allié pour un rendement énergétique maximal.
* **L'objectif :** Cette électricité est vitale. Elle alimentera vos raffineries, vos synthétiseurs de carburant et les futurs systèmes de survie de vos bases extra-terrestres.

---

## Le programme Apollo (Northstar Redux)
L'espace est un environnement hostile qui ne pardonne aucune erreur de préparation. Grâce à **Northstar Redux** (et l'intégration de *Mekanism X Create: Northstar*), la galaxie est à votre portée.

* **Le Spatioport :** Avant de viser la Lune ou Mars, vous devez bâtir une véritable infrastructure au sol : des pas de tir robustes, des grues d'assemblage et des cuves de stockage de carburant.
* **L'assemblage des fusées :** Tout comme pour vos dirigeables, concevez vos fusées bloc par bloc. Calculez bien le ratio entre la masse de votre vaisseau, la capacité de vos réservoirs et la puissance de vos propulseurs spatiaux.
* **La survie dans le vide :** L'espace est vide d'air et mortellement froid. Avant le compte à rebours, fabriquez impérativement une combinaison spatiale étanche et remplissez vos bouteilles d'oxygène. Sans cela, le voyage sera de très courte durée.

![Fusée sur son pas de tir prête au lancement](assets/create-northstar_example.png)

---

## L'armement de défense (Create Big Cannons)
L'univers n'est pas toujours pacifique. Que ce soit pour défendre votre spatioport terrestre ou pour armer lourdement vos croiseurs stellaires, préparez votre arsenal.

* **L'artillerie lourde :** Oubliez les petits arcs. Avec **Create Big Cannons**, vous allez fondre, assembler et calibrer des canons gigantesques.
* **Munitions sur mesure :** Chargez vos canons avec de la poudre et choisissez vos obus selon la situation (perforants pour percer les blindages, explosifs pour les dégâts de zone).
* **Tourelles embarquées :** La grande force de ce mod est que vous pouvez monter ces immenses canons directement sur vos structures mobiles (dirigeables et vaisseaux) pour les transformer en véritables cuirassés volants.

![Canon lourd monté sur la tourelle d'un vaisseau](assets/create-big-cannons_example.png)