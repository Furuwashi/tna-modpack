---
navigation:
  # Title shown in the navigation bar
  title: Create
  # [OPTIONAL] The page ID of the parent this page should be sorted under as a child entry
  # If it's in the same namespace as the current page, the namespace can be omitted, otherwise use "ae2:path/to/file.md"
  parent: guide_technologie.md
  # [OPTIONAL] The position of this page in the navigation bar as a number
  # Pages are sorted by their position value with the title acting as a tie-breaker
  position: 1
---

## 1. L'univers "Create" et ses Add-ons (L'ingénierie mécanique)

Create est le cœur du serveur, mais ses add-ons repoussent ses limites. Au lieu d'utiliser de l'électricité magique, ici tout tourne autour de l'énergie cinétique (les engrenages et les roues qui tournent). 

### Mobilité et Logistique
* **Create Aeronautics :** Pour construire de véritables dirigeables et navires volants contrôlables. Le ciel est votre domaine.
* **Create: Steam 'n' Rails 1.21.1 :** Pour des réseaux ferroviaires massifs. Ajoute de nouveaux types de rails, des trains beaucoup plus complexes et des chefs de gare pour une logistique parfaite.

### Nouvelles Énergies
* **Create Diesel Generators & Create Nuclear :** Marre des moulins à eau ? Passez au carburant lourd ou carrément à l'énergie nucléaire pour faire tourner vos machines à une vitesse folle et alimenter de gigantesques usines.
* **Create: New Age :** La transition parfaite. Ce mod permet de créer un pont entre l'énergie cinétique (Create) et l'électricité classique (pour alimenter vos autres machines industrielles).

### Automatisation Spécialisée
* **Create: Enchantment Industry :** La magie industrialisée. Manipulez l'expérience sous forme liquide, automatisez l'enchantement et clonez vos livres à la chaîne.
* **Create: Central Kitchen & Create: Food :** Le rêve de tout cuisinier. Permet d'automatiser entièrement la production de nourriture complexe, de la récolte jusqu'au plat cuisiné.
* **Create: Power Loader :** L'outil indispensable pour que vos trains et usines continuent de fonctionner en votre absence en gardant les zones de la carte actives.

### Armement
* **Create Big Cannons :** Fondez et assemblez d'immenses canons. Chargez les obus et la poudre pour défendre votre base ou armer lourdement votre dirigeable contre d'éventuelles menaces.

### Construction et Décoration
* **Create Deco & Create: Interiors :** Offre une multitude de nouveaux éléments décoratifs, des briques industrielles, des passerelles et des meubles pour sublimer vos usines.
* **Create: Copycats+ :** Repousse les limites architecturales en ajoutant de nouvelles formes de blocs capables d'imiter la texture de n'importe quel autre matériau.

### Outils et Équipements
* **Create Stuff & Additions :** Enrichit votre arsenal avec de nouveaux équipements de survie, des outils et des armures basés sur le laiton et le cuivre.
* **Create: More Drill Heads :** Ajoute des têtes de forage de différents niveaux (fer, diamant, netherite...) pour accélérer et optimiser vos immenses machines d'excavation.

### Exploration et Génération
* **Create: Rustic Structures & Create: Structures Arise :** Rend l'exploration beaucoup plus vivante en intégrant des structures générées dans le monde qui utilisent nativement des mécanismes Create.
* **Create: Oh The Biomes We've Gone Compat :** Assure une parfaite intégration des blocs et recettes Create avec les magnifiques environnements de ce mod de biomes.
* **Create: Deep Dark & Create: Dragons Plus :** Étend les possibilités mécaniques aux profondeurs sombres et ajoute des interactions épiques (dont des dragons !) pour corser vos aventures.
* **Create: Rock & Stone :** Enrichit la génération souterraine et le minage pour des expéditions de récolte de ressources plus variées.

### Immersion
* **Create: Sound of Steam :** Sublime l'ambiance de vos usines avec de nouveaux effets sonores de vapeur et de mécanismes pour une immersion industrielle absolue.