---
navigation:
  # Title shown in the navigation bar
  title: Ma première base
  # [OPTIONAL] The page ID of the parent this page should be sorted under as a child entry
  # If it's in the same namespace as the current page, the namespace can be omitted, otherwise use "ae2:path/to/file.md"
  parent: index.md
  # [OPTIONAL] The position of this page in the navigation bar as a number
  # Pages are sorted by their position value with the title acting as a tie-breaker
  position: 3
---

# 3. Ma première base (S'installer)

Vous avez survécu à vos premières nuits et vos poches sont pleines. Il est temps de vous sédentariser. Cette étape est cruciale pour préparer l'arrivée de l'industrie lourde et de vos futurs véhicules.

---

## <ItemImage id="draconicevolution:item_chaotic_shield_capacity"/> Protéger son terrain (Open Parties and Claims)
Ne laissez pas les creepers (ou vos voisins) ruiner vos constructions. Il est primordial de protéger votre base.

* **Revendiquer (Claim) un terrain :** Ouvrez la carte de gestion des claims (via un bouton en haut à gauche de l'inventaire ou une touche dédiée). Cliquez sur les chunks (carrés de 16x16 blocs) que vous souhaitez vous approprier. Les autres joueurs ne pourront plus y construire ou casser des blocs.
* **Le point crucial (Les Fake Players) :** Notre serveur utilise beaucoup de machines autonomes avec le mod Create (comme les foreuses ou les scies). Ces machines agissent comme de "faux joueurs". Dans les paramètres de vos chunks protégés (via le menu de votre groupe/party), vous devez impérativement autoriser les "Fake Players". Sinon, vos machines Create refuseront de fonctionner sur votre propre terrain !

---

## <ItemImage id="create:cardboard_package_12x12"/> Le stockage intelligent (Sophisticated Storage)
Oubliez les immenses salles remplies de dizaines de coffres en bois désorganisés.

* **Coffres améliorés :** Tout comme les sacs à dos, vous pouvez améliorer vos coffres (fer, or, diamant...) pour qu'ils stockent énormément plus d'objets sur un seul et même bloc.
* **Barils (Barrels) :** Parfaits pour les ressources que vous possédez en grande quantité (comme la pierre ou la terre). L'icône de l'objet s'affiche directement sur la face du baril, ce qui est idéal pour s'y retrouver d'un coup d'œil dans vos minerais.
* **Améliorations :** Vous pouvez insérer des modules (Upgrades) dans vos coffres et barils pour qu'ils trient, compressent ou aspirent automatiquement les objets à proximité.

![Interface d'un baril avec améliorations](assets/sophisticated-storage_example.png)
![Exemple de mur de stockage avec barils](assets/sophisticated-storage_barrel_wall_example.png)

---

## <ItemImage id="create:cogwheel"/> Les bases de l'énergie (Create)
C'est ici que l'automatisation commence vraiment. Pour l'instant, le mod Create n'utilise pas d'électricité classique, mais de l'énergie cinétique (la force du mouvement mécanique).

* **Générer de l'énergie :** La méthode la plus simple et accessible pour débuter est la Roue à eau (Water Wheel). Placez-la de manière à ce que l'eau coule sur ses pales pour la faire tourner.
* **Transmettre le mouvement :** Utilisez des Arbres de transmission (Shafts) et des Roues dentées (Cogwheels) pour acheminer la force de votre roue à eau jusqu'à vos machines. Les roues dentées permettent de créer des engrenages pour accélérer ou ralentir la vitesse de rotation.
* **Vos premières machines :** Commencez par automatiser les tâches répétitives. Branchez une Meule (Millstone) pour moudre votre blé ou broyer des minerais plus efficacement, ou installez une Scie mécanique (Mechanical Saw) pour débiter votre bois sans effort.

![Installation basique d'une roue à eau Create](assets/create_waterwheel_example.png)